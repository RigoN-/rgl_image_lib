#ifndef GLH_CONVENIENCE_H
#define GLH_CONVENIENCE_H

// Convenience methods for using glh_linear objects
// with opengl...


#include <glh_linear.h>
#include <GL/gl.h>
#include <GL/glu.h>

namespace glh
{

  // per-vertex helpers

  void color(const vec3f & c) { glColor3fv(&c[0]); }
  void color(const vec4f & c) { glColor4fv(&c[0]); }

  void normal(const vec3f & n) { glNormal3fv(&n[0]); }

  void texcoord(const vec2f & t) { glTexCoord2fv(&t[0]); }
  void texcoord(const vec3f & t) { glTexCoord3fv(&t[0]); }
  void texcoord(const vec4f & t) { glTexCoord4fv(&t[0]); }

  void vertex(const vec2f & v) { glVertex2fv(&v[0]); }
  void vertex(const vec3f & v) { glVertex3fv(&v[0]); }
  void vertex(const vec4f & v) { glVertex4fv(&v[0]); }

  // lighting helpers

  void material(GLenum face, GLenum pname, GLint i)
  { glMateriali(face, pname, i); }

  void material(GLenum face, GLenum pname, GLfloat f)
  { glMaterialf(face, pname, f); }

  void material(GLenum face, GLenum pname, const vec4f & v)
  { glMaterialfv(face, pname, &v[0]); }

  void light(GLenum light, GLenum pname, GLint i)
  { glLighti(light, pname, i); } 

  void light(GLenum light, GLenum pname, GLfloat f)
  { glLightf(light, pname, f); } 

  void light(GLenum light, GLenum pname, const vec4f & v)
  { glLightfv(light, pname, &v[0]); } 

  // transform helpers

  void rotate(const rotationf & r)
  {
	float angle;
	vec3f axis;
	r.get_value(axis, angle);
	glRotatef(to_degrees(angle), axis[0], axis[1], axis[2]);
  }

  void translate(const vec3f & t)
  {
	glTranslatef(t[0], t[1], t[2]);
  }

  void scale(const vec3f & s)
  {
 	glScalef(s[0], s[1], s[2]);
  }

  void lookat(const vec3f & eye, const vec3f & look, const vec3f & up)
  {
	gluLookAt(eye[0], eye[1], eye[2],
		  look[0], look[1], look[2],
		  up[0], up[1], up[2]);
  }

  // matrix helpers

  matrix4f get_matrix(GLenum matrix) 
  {
	GLfloat m[16];
	glGetFloatv(matrix, m);
	
	return matrix4f(m);
  }

  void load_matrix(const matrix4f & m)
  {
	matrix4f m2(m.transpose());
	// matrix4f is row-major, so we must transpose
	// before we get the pointer...
	glLoadMatrixf(m2[0]);	
  }

  void mult_matrix(const matrix4f & m)
  {
	matrix4f m2(m.transpose());
	// matrix4f is row-major, so we must transpose
	// before we get the pointer...
	glMultMatrixf(m2[0]);	
  }

  matrix4f frustum(float left, float right,
				   float bottom, float top,
				   float zNear, float zFar)
  {
	matrix4f m;
	m.make_identity();

	m[0][0] = (2*zNear) / (right - left);
	m[0][2] = (right + left) / (right - left);
	
	m[1][1] = (2*zNear) / (top - bottom);
	m[1][2] = (top + bottom) / (top - bottom);
	
	m[2][2] = -(zFar + zNear) / (zFar - zNear);
	m[2][3] = -2*zFar*zNear / (zFar - zNear);
   
	m[3][2] = -1;
	m[3][3] = 0;

	return m;
  }

  matrix4f frustum_inverse(float left, float right,
						   float bottom, float top,
						   float zNear, float zFar)
  {
	matrix4f m;
	m.make_identity();

	m[0][0] = (right - left) / (2 * zNear);
	m[0][3] = (right + left) / (2 * zNear);
	
	m[1][1] = (top - bottom) / (2 * zNear);
	m[1][3] = (top + bottom) / (2 * zNear);

	m[2][2] = 0;
	m[2][3] = -1;
	
	m[3][2] = -(zFar - zNear) / (2 * zFar * zNear);
	m[3][3] = (zFar + zNear) / (2 * zFar * zNear);

	return m;
  }

  matrix4f perspective(float fovy, float aspect, float zNear, float zFar)
  {
	double tangent = tan(to_radians(fovy/2.0));
	float y = tangent * zNear;
	float x = aspect * y;
	return frustum(-x, x, -y, y, zNear, zFar);
  }

  matrix4f perspective_inverse(float fovy, float aspect, float zNear, float zFar)
  {
	double tangent = tan(to_radians(fovy/2.0));
	float y = tangent * zNear;
	float x = aspect * y;
	return frustum_inverse(-x, x, -y, y, zNear, zFar);
  }

  void set_texgen(GLenum plane_type, const matrix4f & m)
  {
	  GLenum coord[] = {GL_S, GL_T, GL_R, GL_Q };
	  for(int i = 0; i < 4; i++)
	  {
		  glTexGenfv(coord[i], plane_type, m[i]);
	  }
  }

} // namespace glh

#endif

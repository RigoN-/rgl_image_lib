// This is a file for simple GL helper classes...

#ifndef GLH_OBS_H
#define GLH_OBS_H

#ifdef WIN32
# include <windows.h>
#endif

#include <GL/gl.h>

namespace glh
{
	class display_list
	{
	public:
		display_list() 
			: valid(false) {}
		
		virtual ~display_list()
		{ del(); }
		
		void call_list()
		{ if(valid) glCallList(dlist); }
		
		void new_list(GLenum mode)
		{ if(!valid) gen(); glNewList(dlist, mode); }
		
		void end_list()
		{ glEndList(); }
		
		void del()
		{ if(valid) glDeleteLists(dlist, 1); valid = false; }
		
		bool is_valid() const { return valid; }
		
	private:
		
		void gen() { dlist = glGenLists(1); valid=true; }
		
		bool valid;
		GLuint dlist;
	};
	
	
	class tex_object
	{
	public:
		tex_object(GLenum tgt) 
			: target(tgt), valid(false) {}
		
		virtual ~tex_object()
		{ del(); }
		
		void bind()
		{ if(!valid) gen(); glBindTexture(target, texture); }
		
		void unbind()
		{ glBindTexture(target, 0); }
		
		void del()
		{ if(valid) glDeleteTextures(1, &texture); valid = false; }
		
		bool is_valid() const { return valid; }
		
	private:
		
		void gen() { glGenTextures(1, &texture); valid=true; }
		
		bool valid;
		GLuint texture;
		GLenum target;
	};
	
	class tex_object_1D : public tex_object
	{ public: tex_object_1D() : tex_object(GL_TEXTURE_1D) {} };
	
	class tex_object_2D : public tex_object
	{ public: tex_object_2D() : tex_object(GL_TEXTURE_2D) {} };
}
#endif
// some helper classes for making
// and using cube maps

#ifndef GLH_CUBE_MAP_H
#define GLH_CUBE_MAP_H

#include <glh_linear.h>

namespace glh
{

	// make a cube map from a functor
	template <class FunctionOfDirection>
		void make_cube_map(FunctionOfDirection & f, GLenum internal_format,
		int size)
	{
		typedef typename FunctionOfDirection::Type Type;
		int components = f.components;
		GLenum type = f.type;
		GLenum format = f.format;
		Type * image  = new Type[size*size*components];
		Type * ip;

		float offset = .5;
		float delta = 1;
		float halfsize = size/2.f;
		vec3f v;

		// positive x image	
		{
			ip = image;
			for(int j = 0; j < size; j++)
			{
				for(int i=0; i < size; i++)
				{
					v[2] = -(i*delta + offset - halfsize);
					v[1] = -(j*delta + offset - halfsize);
					v[0] = halfsize;
					v.normalize();
					f(v, ip);
					ip += components;
				}
			}
			glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X_EXT,
						 0, internal_format, size, size, 0, format, type, image);
		}
		// negative x image	
		{
			ip = image;
			for(int j = 0; j < size; j++)
			{
				for(int i=0; i < size; i++)
				{
					v[2] = (i*delta + offset - halfsize);
					v[1] = -(j*delta + offset - halfsize);
					v[0] = -halfsize;
					v.normalize();
					f(v, ip);
					ip += components;
				}
			}
			glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_X_EXT,
						 0, internal_format, size, size, 0, format, type, image);
		}

		// positive y image	
		{
			ip = image;
			for(int j = 0; j < size; j++)
			{
				for(int i=0; i < size; i++)
				{
					v[0] = (i*delta + offset - halfsize);
					v[2] = (j*delta + offset - halfsize);
					v[1] = halfsize;
					v.normalize();
					f(v, ip);
					ip += components;
				}
			}
			glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Y_EXT,
						 0, internal_format, size, size, 0, format, type, image);
		}
		// negative y image	
		{
			ip = image;
			for(int j = 0; j < size; j++)
			{
				for(int i=0; i < size; i++)
				{
					v[0] = (i*delta + offset - halfsize);
					v[2] = -(j*delta + offset - halfsize);
					v[1] = -halfsize;
					v.normalize();
					f(v, ip);
					ip += components;
				}
			}
			glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y_EXT,
						 0, internal_format, size, size, 0, format, type, image);
		}

		// positive z image	
		{
			ip = image;
			for(int j = 0; j < size; j++)
			{
				for(int i=0; i < size; i++)
				{
					v[0] = (i*delta + offset - halfsize);
					v[1] = -(j*delta + offset - halfsize);
					v[2] = halfsize;
					v.normalize();
					f(v, ip);
					ip += components;
				}
			}
			glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Z_EXT,
						 0, internal_format, size, size, 0, format, type, image);
		}
		// negative z image	
		{
			ip = image;
			for(int j = 0; j < size; j++)
			{
				for(int i=0; i < size; i++)
				{
					v[0] = -(i*delta + offset - halfsize);
					v[1] = -(j*delta + offset - halfsize);
					v[2] = -halfsize;
					v.normalize();
					f(v, ip);
					ip += components;
				}
			}
			glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z_EXT,
						 0, internal_format, size, size, 0, format, type, image);
		}
		delete [] image;
	}

	
	struct vector_unity
	{
		typedef GLfloat Type;
		int components;
		GLenum type;
		GLenum format;
		vector_unity() : components(3), format(GL_RGB), type(GL_FLOAT) {}
		
		void operator() (const vec3f & v, Type * t)
		{
			vec3f v2 = v;
			v2 *= .5;
			v2 += .5;
			t[0] = v2[0];
			t[1] = v2[1];
			t[2] = v2[2];
		}
	};
}

#endif


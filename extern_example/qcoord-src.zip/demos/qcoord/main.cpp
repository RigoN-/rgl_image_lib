#ifdef WIN32
#include <windows.h>
#endif

#include <glh_glut.h>
#include <glh_obs.h>

using namespace glh;

glut_callbacks cb;
glut_pan pan;
glut_dolly dolly;
glut_trackball trackball;

void key(unsigned char k, int x, int y);
void display();
void reshape(int w, int h);
void menu(int entry);
void timer(int id);

bool b[256];
float top = .3;
bool use_q = false;
bool animating = true;
float scale_texcoord = 1.f;

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
	glutCreateWindow("Getting to know the q texture coordinate...");

	glut_helpers_initialize();

	cb.keyboard_function = key;
	pan.activate_on = GLUT_MIDDLE_BUTTON;
	dolly.activate_on = GLUT_LEFT_BUTTON;
	dolly.modifiers = GLUT_ACTIVE_CTRL;
	dolly.dolly[2] = -2; // push the camera back...

	glut_helpers_initialize();
	glut_add_interactor(&cb);
	glut_add_interactor(&pan);
	glut_add_interactor(&dolly);
	glut_add_interactor(&trackball);

	glutCreateMenu(menu);
	glutAddMenuEntry("Use STRQ Coords [c]", 'c');
	glutAddMenuEntry("Use only ST Coords [C]", 'C');
	glutAddMenuEntry("Toggle texture animation [a]", 'a');
	glutAddMenuEntry("Make Quad Trapezoidal [1]", '1');
	glutAddMenuEntry("Make Quad Square [2]", '2');
	glutAddMenuEntry("Increase top width [t]", 't');
	glutAddMenuEntry("Decrease top width [T]", 'T');
	glutAddMenuEntry("Reset STRQ scale factor [r]", 'r');
	glutAddMenuEntry("Quit [<esc>]", 27);
	glutAddMenuEntry("----------------------------", 0);
	glutAddMenuEntry("Use [d] and [D] to adjust the STRQ scale factor", 0);
	glutAddMenuEntry("Use [t] and [T] to adjust the quad's top width", 0);

	glutAttachMenu(GLUT_RIGHT_BUTTON);
	
	glMatrixMode(GL_TEXTURE);
	glScalef(5,5,1);
	glMatrixMode(GL_MODELVIEW);
	
#   define TEX_SIZE 16
	GLfloat tex[TEX_SIZE][TEX_SIZE];
	int half = TEX_SIZE >> 1;

	for(int i=0; i < TEX_SIZE; i++)
		for(int j=0; j < TEX_SIZE; j++)
		{
			if(i < half && j < half) tex[i][j] = 1;
			else if(i >= half && j >= half) tex[i][j] = 1;
			else tex[i][j] = 0;
		}

	glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, TEX_SIZE, TEX_SIZE, 0, GL_LUMINANCE, GL_FLOAT, tex);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glEnable(GL_TEXTURE_2D);

	// add some fog to help depth perception...
	GLfloat zero[] = {.1,.1,.1,.1};
	glFogi(GL_FOG_MODE, GL_LINEAR);
	glFogf(GL_FOG_START, .5);
	glFogf(GL_FOG_END, 3);
	glFogfv(GL_FOG_COLOR, zero);
	glEnable(GL_FOG);

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glutTimerFunc(33, timer, 0);
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);

	glutMainLoop();
	return 0;
}

void timer(int id)
{
	if(animating)
	{
		glutTimerFunc(33, timer, 0);
		glMatrixMode(GL_TEXTURE);
		glTranslatef(0, .01, 0);
		glMatrixMode(GL_MODELVIEW);
		glutPostRedisplay();
	}
}

void menu(int entry)
{
	key((unsigned char)entry, 0, 0);
}

void reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	float a = float(w)/float(h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, a, .1, 4);
	glMatrixMode(GL_MODELVIEW);
}


void key(unsigned char k, int x, int y)
{
	b[k] = ! b[k];
	if(k == 27) exit(0);
	if(k == 'a')
	{
		animating = !animating;
		if(animating) glutTimerFunc(33, timer, 0);
	}
	if(k == 't')
	{
		top += .05;
	}
	if(k == 'T')
	{
		top -= .05;
	}
	if(k == 'c')
	{
		use_q = true;
	}
	if(k == 'C')
	{
		use_q = false;
	}
	if(k == '1') // trapezoid
	{
		top = .3;
	}
	if(k == '2') // square
	{
		top = 1;
	}
	if(k == 'd') scale_texcoord += .05;
	if(k == 'D') scale_texcoord -= .05;
	if(k == 'r') scale_texcoord = 1;

	glutPostRedisplay();
}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glPushMatrix();

	pan.apply_transform();
	dolly.apply_transform();
	trackball.apply_transform();


	if(use_q)
	{
		float tx = scale_texcoord * top;
		glBegin(GL_QUADS);
		
		glTexCoord2f(-1, -1);
		glVertex2f  (-1, -1);
		
		glTexCoord4f(-tx,  tx, 0, tx);
		glVertex2f  (-top,  1);
		
		glTexCoord4f( tx,  tx, 0, tx);
		glVertex2f  ( top,  1);
		
		glTexCoord2f( 1, -1);
		glVertex2f  ( 1, -1);
		
		glEnd();
	}
	else
	{
		glBegin(GL_QUADS);
		
		glTexCoord2f(-1, -1);
		glVertex2f  (-1, -1);
		
		glTexCoord2f(-1,  1);
		glVertex2f  (-top,  1);
		
		glTexCoord2f( 1,  1);
		glVertex2f  ( top,  1);
		
		glTexCoord2f( 1, -1);
		glVertex2f  ( 1, -1);
		
		glEnd();
	}

	glPopMatrix();
	glutSwapBuffers();
}


